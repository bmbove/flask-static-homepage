#!/usr/bin/env python

# slimrio - SLIMP3 emulation for the Rio Receiver.
#
# ssdp.py: Listen for port 21075 broadcast UDP and reply with
# address of NFS server.
#
# Copyright (C) 2007 Robin O'Leary <slimrio@ro.nu>
#
# See also http://empeg.org.uk/slimrio/
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import sys
import socket

try:
	host=sys.argv[1]
except:
	host=socket.gethostname()

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(("", 21075));

while True:
	(request, clientaddr)=s.recvfrom(1024)
	print clientaddr[0], request.split()[1]
	s.sendto("http://"+socket.gethostbyname(host)+"/descriptor.xml\n", clientaddr)
